## ----setup, include=FALSE, message=FALSE---------------------------------
knitr::opts_chunk$set(fig.width=7, fig.height=5)
library(MazamaCoreUtils)
library(AirSensor)
library(dplyr)
library(ggplot2)
# NOTE: Use example PAS and PAT data for vignettes to avoid long wait-times
pas <- AirSensor::example_pas
pat <- AirSensor::example_pat

## ----names---------------------------------------------------------------
pat %>%
  names()

## ----allPlot-------------------------------------------------------------
pat %>%
  pat_multiplot(plottype = "all")

## ----pm25Plot------------------------------------------------------------
pat %>%
  pat_multiplot(plottype = "pm25")

## ----augustPlot----------------------------------------------------------
pat_august <- 
  pat %>% 
  pat_filterDate(startdate = 20180801, enddate = 20180901)

pat_august %>%
  pat_multiplot(plottype = "pm25")

## ----outlierPlot---------------------------------------------------------
pat_august_filtered <- 
  pat_august %>%
  pat_outliers(replace = TRUE, showPlot = TRUE)

## ------------------------------------------------------------------------
august_14 <- 
  pat_august %>% 
  pat_filterDate(startdate = 20180814, days = 1)

august_14 %>% 
  pat_multiplot(plottype = "all")

