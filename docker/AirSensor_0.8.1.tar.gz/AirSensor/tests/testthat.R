library(testthat)
library(AirSensor)

test_check("AirSensor")
