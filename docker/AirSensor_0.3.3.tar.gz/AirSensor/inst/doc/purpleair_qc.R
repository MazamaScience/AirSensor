## ----setup, include=FALSE, message=FALSE---------------------------------
knitr::opts_chunk$set(fig.width=7, fig.height=5)
library(AirSensor)

## ----example_pat_basic---------------------------------------------------
pat <- example_pat %>% pat_filterDate(20180701, 20180708)
# use sampleSize = NULL to force display of every data point
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_basic-------------------------------------------
pat <- example_pat_failure
# use sampleSize = NULL to force display of every data point
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_B_basic-----------------------------------------
pat <- example_pat_failure_B
# use sampleSize = NULL to force display of every data point
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_qc1---------------------------------------------
pat <-
  example_pat_failure %>%
  pat_qc()
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_B_qc1-------------------------------------------
pat <-
  example_pat_failure_B %>%
  pat_qc()
pat_multiplot(pat, sampleSize = NULL)


## ----pat_aggregate-------------------------------------------------------
df <-
  example_pat_failure %>%
  pat_qc() %>%
  pat_aggregate(period = "1 hour")
class(df)
names(df)

## ----AB_boxplot----------------------------------------------------------
library(ggplot2)

# Grab a 1-day subset of the data
raw_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190611,20190611) %>%
  pat_extractData() %>%
  dplyr::select(datetime, pm25_A, pm25_B) %>%
  # Convert datetime to an hourly timestamp to use as a factor
  dplyr::mutate(datetime = strftime(datetime, "%Y%m%d%H")) %>%
  # Convert from wide to "tidy" so we can use channel as a factor
  tidyr::gather("channel", "pm25", -datetime)

# Look at a random sample of this new dataframe
dplyr::sample_n(raw_data, 10)

# Create a timeseries using boxplots
colors <- c(rgb(0.9, 0.25, 0.2), rgb(0.2, 0.25, 0.9))
ggplot(raw_data, aes(datetime, pm25, color = channel)) + 
  geom_boxplot(outlier.shape = NA,
               show.legend = FALSE) +
  scale_color_manual(values=colors) +
  geom_jitter(cex = 0.2) +
  ggtitle("A/B hourly averages")

# Compare the t-statistic for that day
agg_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190611,20190611) %>%
  pat_aggregate()

ggplot(agg_data, aes(datetime, pm25_t)) +
  geom_point() +
  scale_y_log10() + 
  ggtitle("t-statistic")

## ----AB_boxplot_2, echo = FALSE------------------------------------------
library(ggplot2)

# Grab a 1-day subset of the data
raw_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190612,20190612) %>%
  pat_extractData() %>%
  dplyr::select(datetime, pm25_A, pm25_B) %>%
  # Convert datetime to an hourly timestamp to use as a factor
  dplyr::mutate(datetime = strftime(datetime, "%Y%m%d%H")) %>%
  # Convert from wide to "tidy" so we can use channel as a factor
  tidyr::gather("channel", "pm25", -datetime)

# Look at a random sample of this new dataframe
dplyr::sample_n(raw_data, 10)

# Create a timeseries using boxplots
colors <- c(rgb(0.9, 0.25, 0.2), rgb(0.2, 0.25, 0.9))
ggplot(raw_data, aes(datetime, pm25, color = channel)) + 
  geom_boxplot(outlier.shape = NA,
               show.legend = FALSE) +
  scale_color_manual(values=colors) +
  geom_jitter(cex = 0.2) +
  ggtitle("A/B hourly averages")

# Compare the t-statistic for that day
agg_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190612,20190612) %>%
  pat_aggregate()

ggplot(agg_data, aes(datetime, pm25_t)) +
  geom_point() +
  scale_y_log10() + 
  ggtitle("t-statistic")

## ----example_qc, eval = FALSE--------------------------------------------
#  hourlyData <-
#    example_pat_failure %>%
#    # Apply out-of-spec QC
#    pat_qc() %>%
#    # Calculate aggregation statistics
#    pat_aggregate(period = "1 hour") %>%
#    # Average together both channels
#    dplyr::mutate(pm25 = (pm25_A_mean + pm25_B_mean) / 2) %>%
#    # Invalidate data where either channel has too few measurements
#    dplyr::mutate(pm25 = replace(pm25, which(pm25_A_count < 10), NA) ) %>%
#    dplyr::mutate(pm25 = replace(pm25, which(pm25_B_count < 10), NA) ) %>%
#    # Invlidate data where t-test is too high
#    dplyr::mutate(pm25 = replace(pm25, which(abs(pm25_t) > 100), NA) ) %>%
#    dplyr::select(datetime, pm25)
#  
#  plot(hourlyData)

## ----hourly_barplots, echo = FALSE, warning = FALSE----------------------

suppressPackageStartupMessages({
  library(PWFSLSmoke)
})

pat_hourlyData <- function(
  pat
) {
  
  hourlyData <-
    pat %>%
    # Apply out-of-spec QC
    pat_qc() %>%
    # Calculate aggregation statistics
    pat_aggregate(period = "1 hour") %>%
    # Average together both channels
    dplyr::mutate(pm25 = (pm25_A_mean + pm25_B_mean) / 2) %>%
    # Invalidate data where either channel has too few measurements
    dplyr::mutate(pm25 = replace(pm25, which(pm25_A_count < 10), NA) ) %>%
    dplyr::mutate(pm25 = replace(pm25, which(pm25_B_count < 10), NA) ) %>%
    # Invlidate data where t-test is too high
    dplyr::mutate(pm25 = replace(pm25, which(abs(pm25_t) > 100), NA) ) %>%
    dplyr::select(datetime, pm25)
  
  return(hourlyData)

}

layout(matrix(seq(3)))
hourlyData <- example_pat %>% 
  pat_filterDate(20180701, 20180708) %>%
  pat_hourlyData()
plot(hourlyData, type='h', lwd=2, main = 'example_pat')

hourlyData <- example_pat_failure %>% 
  pat_hourlyData()
plot(hourlyData, type='h', lwd=2, main = 'example_pat_failure')

hourlyData <- example_pat_failure_B %>% 
  pat_hourlyData()
plot(hourlyData, type='h', lwd=2, main = 'example_pat_failure_B')

