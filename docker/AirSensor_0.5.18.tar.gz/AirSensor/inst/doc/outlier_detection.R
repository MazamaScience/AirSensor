## ----setup, include=FALSE, message=FALSE--------------------------------------
knitr::opts_chunk$set(fig.width=7, fig.height=5)
library(AirSensor)

## ----quick_example------------------------------------------------------------
pat <- 
  AirSensor::example_pat %>%
  pat_filterDate("2018-08-01","2018-08-07")

pat_multiplot(pat, plottype = "pm25", sampleSize = 1e6)

## ----pat_outliers-------------------------------------------------------------
pat_outliers(pat, showPlot = TRUE)

## ----visual_inspection--------------------------------------------------------
oneDayData <- 
  pat %>% 
  pat_filterDate("2018-08-03", days = 1) %>%
  pat_extractData()

# Visually inspect for outliers
plot(oneDayData$datetime, oneDayData$pm25_A, 
     xlab = "Aug 1, 21018", ylab = "ug/m3", las = 1)
title("A channel PM2.5")

## ----find_outliers------------------------------------------------------------
# Find the outliers
seismicRoll::findOutliers(oneDayData$pm25_A)

## ----hampel_window------------------------------------------------------------
# Set example point, neighbors, median, and window
windowWidth <- 23
halfWidth <- round(23/2)
exampleIndex <- 872
windowStart <- as.integer(exampleIndex - halfWidth)
windowEnd <- as.integer(exampleIndex + halfWidth)
exampleNeighbors <- c(windowStart:(exampleIndex - 1), (exampleIndex + 1):windowEnd)
windowMedian <- median(oneDayData$pm25_A[exampleNeighbors], na.rm = TRUE)
windowSd <- sd(oneDayData$pm25_A[exampleNeighbors], na.rm = TRUE)

# Plot the window around the example point along with the window median
plot(oneDayData$datetime_A[windowStart:windowEnd], 
     oneDayData$pm25_A[windowStart:windowEnd],
     col = "black", pch = 16, cex = 1,
     main = paste0("Window Around Measurement #", exampleIndex),
     las = 1, xlab = "Time (UTC)", ylab = "PM 2.5 (ug/m3)")
points(oneDayData$datetime_A[exampleIndex], 
       oneDayData$pm25_A[exampleIndex],
       col = "red", pch = 16, cex = 1)
# Add lines for the median and several standard deviations beyond
abline(h = windowMedian, col = "blue")
abline(h = windowMedian + 1:8 * windowSd, 
       lty = "dashed", col = "orange")
# Add a legend
legend(x = "topright",
       legend = c("Point of Interest", 
                  "Neighbors", 
                  paste0("Median = ", round(windowMedian,2)),
                  paste0("Stddev = ", round(windowSd,2))),
       col = c("red", "black", "blue", "orange"),
       lwd = c(1,1,2,2), 
       lty = c(NA, NA, "solid", "dashed"), 
       pch = c(16, 16, NA, NA))


## ----hampel_smoothing_0-------------------------------------------------------
pat2Day <-
  pat_filterDate(pat, "2018-08-02", days = 2)

# No outlier replacement
pat2Day %>% pat_multiplot("pm25", sampleSize = 1e6)

## ----hampel_smoothing_1-------------------------------------------------------
# Default outlier replacement
pat2Day %>%
  pat_outliers(windowSize = 23, thresholdMin = 8, replace = TRUE) %>%
  pat_multiplot("pm25", sampleSize = 1e6)

## ----hampel_smoothing_2-------------------------------------------------------
# Aggressive outlier replacement 
pat2Day %>%
  pat_outliers(windowSize = 23, thresholdMin = 4, replace = TRUE) %>%
  pat_multiplot("pm25", sampleSize = 1e6)

