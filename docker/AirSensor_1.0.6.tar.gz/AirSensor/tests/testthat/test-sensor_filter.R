context('test-sesnor_filter')
data("example_sensor")
test_that(
  'filter works', 
  expect_length(
    sensor_filter(
      example_sensor, 
      .data$datetime > lubridate::ymd_h(2018081500), 
      .data$datetime < lubridate::ymd_h(2018081600)
      )$data$datetime, 
    23
  )
)
