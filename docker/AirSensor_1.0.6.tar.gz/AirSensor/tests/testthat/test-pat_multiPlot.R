# context('test-pat_multiPlot')
# data('example_pat', 'example_sensor')
# 
# test_that(
#   'Plot return classes are correct', 
#   expect_s3_class(
#     pat_multiPlot(example_pat),
#     c('gg', 'ggplot')
#   )
# )
