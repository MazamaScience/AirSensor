## ----setup, include=FALSE, message=FALSE---------------------------------
knitr::opts_chunk$set(fig.width=7, fig.height=5)
library(AirSensor)

## ----example_pat_basic---------------------------------------------------
pat <- example_pat %>% pat_filterDate(20180701, 20180708)
# use sampleSize = NULL to force display of every data point
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_A_basic-----------------------------------------
data("example_pat_failure_A")
pat <- example_pat_failure_A
# use sampleSize = NULL to force display of every data point
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_B_basic-----------------------------------------
data("example_pat_failure_B")
pat <- example_pat_failure_B
# use sampleSize = NULL to force display of every data point
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_A_qc1-------------------------------------------
pat <-
  example_pat_failure_A %>%
  pat_qc()
pat_multiplot(pat, sampleSize = NULL)

## ----example_pat_failure_B_qc1-------------------------------------------
pat <-
  example_pat_failure_B %>%
  pat_qc()
pat_multiplot(pat, sampleSize = NULL)


## ----pat_aggregate-------------------------------------------------------
df <-
  example_pat_failure_A %>%
  pat_qc() %>%
  pat_aggregate(period = "1 hour")
class(df)
names(df)

## ----AB_boxplot----------------------------------------------------------
library(ggplot2)

# Always specify a timezone wherever possible!
timezone <- "America/Los_Angeles"

# Grab a 1-day subset of the data
raw_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190611,20190612) %>%
  pat_extractData() %>%
  dplyr::select(datetime, pm25_A, pm25_B) %>%
  # Convert datetime to an hourly timestamp to use as a factor
  dplyr::mutate(datetime = strftime(datetime, "%Y%m%d%H", tz = timezone)) %>%
  # Convert from wide to "tidy" so we can use channel as a factor
  tidyr::gather("channel", "pm25", -datetime)

# Look at a random sample of this new dataframe
dplyr::sample_n(raw_data, 10)

# Create a timeseries using boxplots
colors <- c(rgb(0.9, 0.25, 0.2), rgb(0.2, 0.25, 0.9))
ggplot(raw_data, aes(datetime, pm25, color = channel)) + 
  geom_boxplot(outlier.shape = NA,
               show.legend = FALSE) +
  scale_color_manual(values=colors) +
  geom_point(pch=15, cex=0.2, position = position_jitterdodge()) +
  ggtitle("A/B hourly averages")

# Compare the t-statistic for that day
agg_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190611,20190612) %>%
  pat_aggregate()

ggplot(agg_data, aes(datetime, pm25_p)) +
  geom_point() +
  scale_y_log10() + 
  ggtitle("t-test p-value")

## ----AB_boxplot_2, echo = FALSE------------------------------------------
library(ggplot2)

# Grab a 1-day subset of the data
raw_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190612,20190613) %>%
  pat_extractData() %>%
  dplyr::select(datetime, pm25_A, pm25_B) %>%
  # Convert datetime to an hourly timestamp to use as a factor
  dplyr::mutate(datetime = strftime(datetime, "%Y%m%d%H", tz = timezone)) %>%
  # Convert from wide to "tidy" so we can use channel as a factor
  tidyr::gather("channel", "pm25", -datetime)

# Look at a random sample of this new dataframe
dplyr::sample_n(raw_data, 10)

# Create a timeseries using boxplots
colors <- c(rgb(0.9, 0.25, 0.2), rgb(0.2, 0.25, 0.9))
ggplot(raw_data, aes(datetime, pm25, color = channel)) + 
  geom_boxplot(outlier.shape = NA,
               show.legend = FALSE) +
  scale_color_manual(values=colors) +
  geom_point(pch=15, cex=0.2, position = position_jitterdodge()) +
  ggtitle("A/B hourly averages")

# Compare the t-statistic for that day
agg_data <- 
  example_pat_failure_B %>%
  pat_filterDate(20190612,20190613) %>%
  pat_aggregate()

ggplot(agg_data, aes(datetime, pm25_p)) +
  geom_point() +
  scale_y_log10() + 
  ggtitle("t-test p-value")

## ----hourly_barplots, echo = FALSE, warning = FALSE----------------------
layout(matrix(seq(3)))

example_pat %>%
  pat_filterDate(20180801, 20180808) %>%
  pat_createAirSensor() %>%
  sensor_extractData() %>%
  plot(type = "h", lwd=2, main = "example_pat")

example_pat_failure_A %>%
  pat_filterDate(20190409, 20190417) %>%
  pat_createAirSensor() %>%
  sensor_extractData() %>%
  plot(type = "h", lwd=2, main = "example_pat_failure_A")

example_pat_failure_B %>%
  pat_filterDate(20190611, 20190618) %>%
  pat_createAirSensor() %>%
  sensor_extractData() %>%
  plot(type = "h", lwd=2, main = "example_pat_failure_B")


